# pip install openpyxl
from flask import Flask, render_template, request
import pandas as pd
from werkzeug.datastructures import ImmutableMultiDict
import ast

app = Flask(__name__)

column_names = []

@app.route('/')
def landing():
    # Query to check OEM to be added and return a list
    list_of_dropdown = ['oppo','vivo','apple','samsung']
    return render_template('landing.html', list_of_dropdown = list_of_dropdown)

@app.route('/select_oem',methods = ['POST', 'GET'])
def select_oem():
   if request.method == 'POST':
    df = pd.read_excel(r"C:\Users\Shubha\Desktop\Mahindra\invoice_poc-master\invoice_poc-master\media\babai.xlsx")
    result = request.form
    lol = df.values.tolist()
    column_names = list(df.columns) 
    lol.insert(0, list(df.columns))
    # dict_item = df.to_dict('list')
    return render_template("select_oem.html", result = result, lol = lol)

@app.route('/final_select_oem',methods = ['POST', 'GET'])
def final_select_oem():
   if request.method == 'POST':
    result = request.form
    imd = ImmutableMultiDict(result)
    imd_dict = imd.to_dict(flat=False)
    final_lol = []
    for i in imd_dict:
        if len(imd_dict[i])>3:
            if imd_dict[i][0] == 'on':
                imd_dict[i].insert(0, i)
                final_lol.append(imd_dict[i])
    column_name = ast.literal_eval(imd_dict['column_name'][0])
    column_name.insert(0, " ")
    column_name.insert(0, " ")
    final_lol.insert(0, column_name)

    return render_template("final_select_oem.html", final_lol = final_lol)

@app.route('/thank_you',methods = ['POST'])
def thank_you():
   if request.method == 'POST':
    result = request.form
    imd = ImmutableMultiDict(result)
    imd_dict = imd.to_dict(flat=False)
    final_lol = []
    for i in imd_dict:
        if len(imd_dict[i])>3:
            if imd_dict[i][0] == 'on':
                imd_dict[i].insert(0, i)
                final_lol.append(imd_dict[i])
    column_name = ast.literal_eval(imd_dict['column_name'][0])
    column_name.insert(0, " ")
    column_name.insert(0, " ")
    final_lol.insert(0, column_name)

    return render_template("thank_you.html")

if __name__=="__main__":
    app.run(debug = True)

# In[]

# import pandas as pd
# df = pd.read_excel(r"C:\Users\Shubha\Desktop\Mahindra\invoice_poc-master\invoice_poc-master\media\babai.xlsx")

# dictition =  {'search': [''], '1': ['on', '2022-03-01 00:00:00', '121', 'samsung', 'random', 'cleared'], '2': ['on', '2022-04-01 00:00:00', '1123', 'vivo', 'random', 'pending'], '3': ['on', '2022-04-02 00:00:00', '132', 'oppo', 'random', 'pending'], '4': ['on', '2022-03-02 00:00:00', '1134', 'samsung', 'random', 'cleared'], '5': ['on', '2022-04-04 00:00:00', '156', 'vivo', 'random', 'pending'], '6': ['on', '2022-03-03 00:00:00', '1123', 'oppo', 'random', 'cleared'], '7': ['on', '2022-04-04 00:00:00', '111', 'samsung', 'random', 'pending'], '8': ['on', '2022-04-05 00:00:00', '123', 'oppo', 'random', 'pending'], '9': ['on', '2022-04-06 00:00:00', '1111', 'vivo', 'random', 'pending'], '10': ['on', '2022-04-07 00:00:00', '66', 'samsung', 'random', 'pending'], '11': ['on', '2022-04-08 00:00:00', '777', 'oppo', 'random', 'pending'], '12': ['on', '2022-04-09 00:00:00', '78', 'vivo', 'random', 'pending'], '13': ['on', '2022-04-10 00:00:00', '668', 'samsung', 'random', 'pending'], '14': ['on', '2022-04-11 00:00:00', '4456', 'oppo', 'random', 'pending'], '15': ['on', '2022-04-11 00:00:00', '4487', 'apple', 'random', 'pending']}
# final_lol = []
# for i in dictition:
#     if len(dictition[i])>3:
#         if dictition[i][0] == 'on':
#             dictition[i].insert(0, i)
#             final_lol.append(dictition[i])

# print(final_lol.insert(0, column_names))

# print(dictition)
# lol.insert(0, list(df.columns))
# print(lol)

# %%
